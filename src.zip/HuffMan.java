import java.util.List;
import java.io.IOException;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;

public class HuffMan {
	public static void main(String[] args) {
		
			int i=0, j=0, k=0;
			String s;
			
			int arr[] = new int[27];
			char arr2[] = new char[27];
			
			// a~z , ' ' 입력
			for(i=97; i<123; i++)
			{
				arr2[i-97]=(char)i;
			}
			arr2[26]=' ';
			
			// 파일 내용 담을 리스트
			List<String> list = new ArrayList<String> ();
		
			Path path = Paths.get("C:\\Users\\32144797\\Desktop\\Text data.txt"); // 파일 객체 생성
			Charset cs = StandardCharsets.UTF_8; // 캐릭터 셋 지정
			
			try {
				list = Files.readAllLines(path, cs);
			}catch(IOException e) {e.printStackTrace();}
			
			i=0;
			for(String readLine : list)
			{
				System.out.println(i + "'s list = " + readLine);
				i++;
			}
			
			for(i=0; i<list.size(); i++)
			{
				s = list.get(i); // 한 라인씩 읽어오기
				
				for(j=0; j<s.length(); j++) {
					for(k=97; k<123; k++) // a = 97, z = 123
					{
						if(s.charAt(j)==k) {
							arr[k-97]++;
							break;}
					}
					if(s.charAt(j)==32) // " " = 32
						arr[26]++;
				}
			}
			
			Tree tree = new Tree(arr);
			
			System.out.println();
			
			// 퀵 정렬 응용버전을 통한 배열 정렬
			tree.quickSort(arr, 0, arr.length-1, arr2);
			
			System.out.println();
			
			for(i=0; i<arr.length; i++)
			{
				if(arr[i]!=0) {
				System.out.print(arr2[i] + " ");
				}
			}
			
			System.out.println();
			
			for(i=0; i<arr.length; i++)
			{
				if(arr[i]!=0) {
				System.out.print(arr[i] + " ");
				}
			}
			
			System.out.println("\n");
			
			tree._inorder();
			
			tree.make(arr, arr2, 0, arr2.length-1);
			
			tree._inorder();
						
	}
}