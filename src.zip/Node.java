
public class Node {
	public int data;
	public char data2;
	public Node RL;
	public Node LL;
	public Node Next;
	
	public Node() {};
	
	public Node(int i_data, Node L_next, Node R_next)
	{
		data = i_data; LL = L_next; RL = R_next;
	}
	
	public Node(char c_data, Node L_next, Node R_next)
	{
		data2 = c_data; LL = L_next; RL = R_next;
	}
	
	public Node(int i_data, Node N_next)
	{
		data = i_data; Next = N_next;
	}
}