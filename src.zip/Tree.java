
public class Tree extends Node {
	
	public Node front;
	public Node root;
	public int count;
	
	public Tree() {};
	
	public Tree(int arr[])
	{
		count = 0;
		root = new Node(-1, null, null);
		front = null;
	}
	
	// 삽입 함수
	public boolean _insert(int x)
	{
		Node p = front;
		Node q = null;
		
		if(p==null) {
			front=new Node(x, null);
		}
		else {
			while(p!=null) {
				q=p;
				p=p.Next;
			}
			q.Next = new Node(x, null);
		}
		count++;
		return true;
	}
	
	// 삭제 함수
	public boolean _delete(int x)
	{
		Node p=front;
		Node q=null;
		
		while(true) {
			if(p==null)
				return false;
			else if(p.data == x)
				break;
			else {
				q=p;
				p=p.Next;
			}
		}
		
		if(q==null)
			front=p.Next;
		else if(p.Next==null)
			q.Next=null;
		else
			q.Next=p.Next;
		
		count--;
		return true;		
	}
	
	// 중위 순회 Driver
	public void _inorder()
	{
		inorder(root);
	}

	// 중위 순회 WorkHorse
	public void inorder(Node CurrentNode)
	{
		Node p = root;
		String a = "";
		
		if(CurrentNode.RL!=null)
		{
			System.out.print(CurrentNode.RL.data2 + " ");
			_find_code(a, CurrentNode.RL.data2, p);
			if(CurrentNode.LL!=null)
				inorder(CurrentNode.LL);
		}
		return;
	}
	
	public void _find_code(String a, char data, Node p)
	{
		String concat;
		
		if(p.RL.data2 == data) {
			concat=a.concat("1");
			System.out.println(data + "'s code : " + concat);
		}
		else
		{
			concat=a.concat("0");
			if(p.LL!=null)
			{
				_find_code(concat, data, p.LL);
			}
		}		
		return;
	}
	
	public void quickSort(int[] arr, int left, int right, char[] brr) 
	{ // 퀵 정렬 함수
		int i, j, pivot, temp1;
		char temp2, pivot2;

		if (left < right) // 퀵 정렬을 실행하기 위한 조건
		{
			i = left; j = right; pivot = arr[left]; pivot2 = brr[left]; // left, right, pivot 설정
			
			while (i < j) // 정렬 조건
			{
				while (arr[j] > pivot) j--; // 피벗보다 클 경우 j 이동
				while (i < j && arr[i] <= pivot) i++; // 피벗보다 작을 경우 i 이동

				// arr[i]가 pivot보다 크고, arr[j]가 pivot보다 작은 경우 서로 교체
				temp1 = arr[i];
				temp2 = brr[i];
				arr[i] = arr[j];
				brr[i] = brr[j];
				arr[j] = temp1;
				brr[j] = temp2;
			}

			// 정렬이 끝난 후 pivot과 arr[i] 서로 교체
			arr[left] = arr[i];
			brr[left] = brr[i];
			arr[i] = pivot;
			brr[i] = pivot2;
			quickSort(arr, left, i - 1, brr); // pivot 왼쪽 배열 정렬
			quickSort(arr, i + 1, right, brr); // pivot 오른쪽 배열 정렬
		}
	}

	public void make(int arr[], char brr[], int left, int right)
	{
		Node p = root;
		
		if(arr[right]==0)
			return ;
		
		if(p.RL==null)
			p.RL=new Node(brr[right], null, null);
		else
		{
			while(p.RL!=null) {
				if(p.LL==null)
				{
					p.LL = new Node(-1, null, null);
					p=p.LL;
				}
				else
					p=p.LL;
			}
			p.RL=new Node(brr[right], null, null);
		}
		
		if(right-left>0)
			make(arr, brr, left, right-1);
		else
			return ;
	}
}
